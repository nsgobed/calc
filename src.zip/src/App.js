import Display from './components/Display';
import KeysOps from './components/KeysOps';
import {useState} from 'react';


function App() {
  const [data, setData] = useState('');
  const [result, setResult] = useState(0);
  let number;
  
  const handleClick = (e) =>{
    let newString;
    console.log(Object.values(e)[0]);
    Object.values(e)[0] === 'C'? handleClear(e): Object.values(e)[0] === '='? calculate(data): newString = data + Object.values(e)[0];
    setData(newString);
  }
  const handleChange = (e) =>{
    e.preventDefault();
    setData(e.target.value)
  }

  const handleClear = (e) =>{
    setResult(0);
    setData('');
  }
  const calculate = (dataString) => {
    const operands = dataString.match(/\d/g);
    const operators = dataString.match(/[+-/*]/g);
    const newOperands = operands.map((x) => parseInt(x));
    number = newOperands[0];
    console.log(newOperands);
    console.log('number is', number);

    for(let x = 0; x < operators.length; x++){
        console.log('number', newOperands[x+1]);
        console.log(operators[x]);
        operators[x] === '*'? number *= newOperands[x+1]:
        operators[x] === '/'? number /= newOperands[x+1]:
        operators[x] === '+'? number += newOperands[x+1]:
        number -= newOperands[x+1];        
     }
     
    
    console.log('number is...', number);
    console.log(data + '=',number)

    setResult(number);
  }
  return (
    <form action="" className="App" onSubmit={(e) => e.preventDefault()}>
      <Display data = {data} result = {Number(result)} handleClear={handleClear} handleChange = {handleChange} />
      <KeysOps handleClick ={handleClick} handleClear = {handleClear}/>      
    </form>
  )
}

export default App;
